<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:105:"C:\xampp\Demo\1875822jn8.iask.in\SUST_Sports_2018\public/../application/index\view\interaction\index.html";i:1524553536;s:89:"C:\xampp\Demo\1875822jn8.iask.in\SUST_Sports_2018\application\index\view\common\base.html";i:1524556310;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>Interaction</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/SUST_Sports_2018/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/SUST_Sports_2018/public/static/css/bootstrap.min.css">
  <script src="/SUST_Sports_2018/public/static/js/common.js"></script>
  <script src="/SUST_Sports_2018/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/SUST_Sports_2018/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/SUST_Sports_2018/public/static/css/interaction_style.css" />

  
<script src="/SUST_Sports_2018/public/static/js/interaction.js"></script>

</head>
<body background="/SUST_Sports_2018/public/static/css/../img/index_bg.jpg">
</body>
  <!-- <img src="/SUST_Sports_2018/public/static/css/../img/index_bg.jpg" class="blur"/> -->

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/SUST_Sports_2018/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

<h2>Surprise!!!</h2>
<h4>->奉上经典小游戏<-</h4>

<div style="height:521.5px" class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src='http://jdc.jd.com/fd/demo/waterful/game.html'></iframe>
</div>

<br/>
<h4>一个不够？那就两个！</h4>
<br/>

<div style="height:480px" class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src='http://www.zzfriend.com/demo/youxi/m/xjmt/'></iframe>
</div>

<br/>

<img style="height:150px;width:100%"  src="/SUST_Sports_2018/public/static/css/../img/logo2.jpg"/ class="img-responsive" alt="Responsive image">

    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
