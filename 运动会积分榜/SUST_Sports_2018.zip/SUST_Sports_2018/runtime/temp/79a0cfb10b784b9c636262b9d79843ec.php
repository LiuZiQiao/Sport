<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:109:"C:\inetpub\wwwroot\Web\LocalUser\websustdx\SUST_Sports_2018\public/../application/index\view\event\index.html";i:1524747736;s:99:"C:\inetpub\wwwroot\Web\LocalUser\websustdx\SUST_Sports_2018\application\index\view\common\base.html";i:1524574908;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>SUST Sports 2018</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/websustdx/SUST_sports_2018/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/websustdx/SUST_sports_2018/public/static/css/bootstrap.min.css">
  <script src="/websustdx/SUST_sports_2018/public/static/js/common.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/websustdx/SUST_sports_2018/public/static/css/event_style.css" />

  
<script src="/websustdx/SUST_sports_2018/public/static/js/event.js"></script>

</head>
<body>
</body>
  <img src="/websustdx/SUST_sports_2018/public/static/css/../img/index_bg.jpg" class="blur"/>

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/websustdx/SUST_sports_2018/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

  <div class="tabl">
  <table class="table table-striped  table-bordered  table-hover text-center">

  <h3>赛事预告</h3>

  <thead>
  <tr >
	<th class="text-center">时间</th>
	<th class="text-center">比赛项目</th>
	<th class="text-center">赛次</th>
  </tr>
  </thead>

  <?php if(is_array($matime) || $matime instanceof \think\Collection || $matime instanceof \think\Paginator): if( count($matime)==0 ) : echo "" ;else: foreach($matime as $i=>$mat): ?>
  <tr >
	<td><?php echo $mat['mat_time']; ?></td>
	<td><?php echo $mat['mat_name']; ?></td>
	<td><?php echo $mat['mat_status']; ?></td>
  </tr>
  <?php endforeach; endif; else: echo "" ;endif; ?>

  </table>
</div>

    <button id="querymatch">查询所有赛事</button>

  <br/>
  <div class="table-responsive  tabl">
  </div>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
