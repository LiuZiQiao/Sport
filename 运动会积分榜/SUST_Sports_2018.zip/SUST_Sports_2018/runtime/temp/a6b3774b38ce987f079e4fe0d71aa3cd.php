<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:111:"C:\xampp\Demo\1875822jn8.iask.in\SUST sports Games 2018\public/../application/index\view\interaction\index.html";i:1523111165;s:95:"C:\xampp\Demo\1875822jn8.iask.in\SUST sports Games 2018\application\index\view\common\base.html";i:1523684182;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>Interaction</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/SUST sports Games 2018/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/SUST sports Games 2018/public/static/css/bootstrap.min.css">
  <script src="/SUST sports Games 2018/public/static/js/common.js"></script>
  <script src="/SUST sports Games 2018/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/SUST sports Games 2018/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/SUST sports Games 2018/public/static/css/interaction_style.css" />

  
<script src="/SUST sports Games 2018/public/static/js/interaction.js"></script>

</head>
<body background="/SUST sports Games 2018/public/static/css/../img/index_bg.jpg">

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/SUST sports Games 2018/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

<h3>view 前端视图 互动页</h3>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
