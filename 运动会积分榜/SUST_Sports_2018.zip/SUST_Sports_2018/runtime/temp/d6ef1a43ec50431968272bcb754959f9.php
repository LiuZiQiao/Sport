<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>
一个字符串<?php echo $email; ?>和<?php echo $assihn; ?>