<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:99:"C:\xampp\Demo\1875822jn8.iask.in\SUST Sports 2018\public/../application/admin\view\login\index.html";i:1523868451;}*/ ?>
