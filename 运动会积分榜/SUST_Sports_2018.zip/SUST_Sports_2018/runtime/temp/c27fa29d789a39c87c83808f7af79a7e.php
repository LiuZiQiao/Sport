<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:91:"C:\xampp\Demo\1875822jn8.iask.in\thinkphp\public/../application/index\view\query\index.html";i:1523360247;s:81:"C:\xampp\Demo\1875822jn8.iask.in\thinkphp\application\index\view\common\base.html";i:1523684182;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>Query</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/thinkphp/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/thinkphp/public/static/css/bootstrap.min.css">
  <script src="/thinkphp/public/static/js/common.js"></script>
  <script src="/thinkphp/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/thinkphp/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/thinkphp/public/static/css/query_style.css" />

  
<script src="/thinkphp/public/static/js/query.js"></script>

</head>
<body background="/thinkphp/public/static/css/../img/index_bg.jpg">

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/thinkphp/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

<h3>view 前端视图 查询页</h3>

<br/>

<select id="lev1" name="match_class" onclick="clicklev1(this.value,'<?php echo $match_class_str; ?>')" onchange="changeitem(this.value,'<?php echo $match_class_str; ?>','<?php echo $class_name_str; ?>')">
  <?php if(is_array(\think\Config::get('match_class')) || \think\Config::get('match_class') instanceof \think\Collection || \think\Config::get('match_class') instanceof \think\Paginator): if( count(\think\Config::get('match_class'))==0 ) : echo "" ;else: foreach(\think\Config::get('match_class') as $c=>$volc): ?>
    <option value=<?php echo $volc; ?>><?php echo $volc; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; ?>
</select>

<br/><br/>

<select id="lev2" name="class_item" onclick="clicklev2(this.value,'<?php echo $class_name_str; ?>')" onchange="changename(this.value,'<?php echo $class_name_str; ?>')">
  <?php if(is_array(\think\Config::get('class_1.class_item')) || \think\Config::get('class_1.class_item') instanceof \think\Collection || \think\Config::get('class_1.class_item') instanceof \think\Paginator): if( count(\think\Config::get('class_1.class_item'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_1.class_item') as $i=>$voli): ?>
    <option class="cls1" value=<?php echo $voli; ?>><?php echo $voli; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_2.class_item')) || \think\Config::get('class_2.class_item') instanceof \think\Collection || \think\Config::get('class_2.class_item') instanceof \think\Paginator): if( count(\think\Config::get('class_2.class_item'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_2.class_item') as $i=>$voli): ?>
    <option class="cls2" value=<?php echo $voli; ?>><?php echo $voli; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.class_item')) || \think\Config::get('class_3.class_item') instanceof \think\Collection || \think\Config::get('class_3.class_item') instanceof \think\Paginator): if( count(\think\Config::get('class_3.class_item'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.class_item') as $i=>$voli): ?>
    <option class="cls3" value=<?php echo $voli; ?>><?php echo $voli; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; ?>
</select>

<br/><br/>

<select id="lev3" name="item_name">
  <?php if(is_array(\think\Config::get('class_1.item_1')) || \think\Config::get('class_1.item_1') instanceof \think\Collection || \think\Config::get('class_1.item_1') instanceof \think\Paginator): if( count(\think\Config::get('class_1.item_1'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_1.item_1') as $n=>$voln): ?>
    <option class="nam1" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_1.item_2')) || \think\Config::get('class_1.item_2') instanceof \think\Collection || \think\Config::get('class_1.item_2') instanceof \think\Paginator): if( count(\think\Config::get('class_1.item_2'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_1.item_2') as $n=>$voln): ?>
    <option class="nam2" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_1.item_3')) || \think\Config::get('class_1.item_3') instanceof \think\Collection || \think\Config::get('class_1.item_3') instanceof \think\Paginator): if( count(\think\Config::get('class_1.item_3'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_1.item_3') as $n=>$voln): ?>
    <option class="nam3" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_2.item_1')) || \think\Config::get('class_2.item_1') instanceof \think\Collection || \think\Config::get('class_2.item_1') instanceof \think\Paginator): if( count(\think\Config::get('class_2.item_1'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_2.item_1') as $n=>$voln): ?>
    <option class="nam4" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_2.item_2')) || \think\Config::get('class_2.item_2') instanceof \think\Collection || \think\Config::get('class_2.item_2') instanceof \think\Paginator): if( count(\think\Config::get('class_2.item_2'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_2.item_2') as $n=>$voln): ?>
    <option class="nam5" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_2.item_3')) || \think\Config::get('class_2.item_3') instanceof \think\Collection || \think\Config::get('class_2.item_3') instanceof \think\Paginator): if( count(\think\Config::get('class_2.item_3'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_2.item_3') as $n=>$voln): ?>
    <option class="nam6" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.item_1')) || \think\Config::get('class_3.item_1') instanceof \think\Collection || \think\Config::get('class_3.item_1') instanceof \think\Paginator): if( count(\think\Config::get('class_3.item_1'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.item_1') as $n=>$voln): ?>
    <option class="nam7" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.item_2')) || \think\Config::get('class_3.item_2') instanceof \think\Collection || \think\Config::get('class_3.item_2') instanceof \think\Paginator): if( count(\think\Config::get('class_3.item_2'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.item_2') as $n=>$voln): ?>
    <option class="nam8" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.item_3')) || \think\Config::get('class_3.item_3') instanceof \think\Collection || \think\Config::get('class_3.item_3') instanceof \think\Paginator): if( count(\think\Config::get('class_3.item_3'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.item_3') as $n=>$voln): ?>
    <option class="nam9" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.item_4')) || \think\Config::get('class_3.item_4') instanceof \think\Collection || \think\Config::get('class_3.item_4') instanceof \think\Paginator): if( count(\think\Config::get('class_3.item_4'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.item_4') as $n=>$voln): ?>
    <option class="nam10" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.item_5')) || \think\Config::get('class_3.item_5') instanceof \think\Collection || \think\Config::get('class_3.item_5') instanceof \think\Paginator): if( count(\think\Config::get('class_3.item_5'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.item_5') as $n=>$voln): ?>
    <option class="nam11" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.item_6')) || \think\Config::get('class_3.item_6') instanceof \think\Collection || \think\Config::get('class_3.item_6') instanceof \think\Paginator): if( count(\think\Config::get('class_3.item_6'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.item_6') as $n=>$voln): ?>
    <option class="nam12" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('class_3.item_7')) || \think\Config::get('class_3.item_7') instanceof \think\Collection || \think\Config::get('class_3.item_7') instanceof \think\Paginator): if( count(\think\Config::get('class_3.item_7'))==0 ) : echo "" ;else: foreach(\think\Config::get('class_3.item_7') as $n=>$voln): ?>
    <option class="nam13" value=<?php echo $voln; ?>><?php echo $voln; ?></option>
  <?php endforeach; endif; else: echo "" ;endif; ?>
</select>

<br/>

<div class="Button">
  <button id="queryrank">查询比赛排名</button>
</div>

<div class="table-responsive">
</div>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
