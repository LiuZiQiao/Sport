<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:110:"C:\inetpub\wwwroot\Web\LocalUser\websustdx\SUST_Sports_2018\public/../application/admin\view\manage\index.html";i:1524559202;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>SUST Sports 2018 Manager</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/websustdx/SUST_sports_2018/public/static/css/admin/manage_style.css" />
  <link rel="stylesheet" href="/websustdx/SUST_sports_2018/public/static/css/bootstrap.min.css">
  <script src="/websustdx/SUST_sports_2018/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/bootstrap.min.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/admin/manage.js"></script>
</head>
<body background="/websustdx/SUST_sports_2018/public/static/css/../img/index_bg.jpg">

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/websustdx/SUST_sports_2018/public/static/css/../img/theme.jpg"/>
    </div>

    <div>
      <h4>晋级决赛 / 比赛成绩</h4>
    <div id="div1" class="open1">
          <div id="div2" class="open2"></div>
      </div>
    </div>

    <div id="stat">当前状态：录入比赛成绩排名</div>

    <select id="lev1" name="match_class" onclick="clicklev1(this.value)" onchange="changeitem(this.value)">
      <?php if(is_array(\think\Config::get('match.class')) || \think\Config::get('match.class') instanceof \think\Collection || \think\Config::get('match.class') instanceof \think\Paginator): if( count(\think\Config::get('match.class'))==0 ) : echo "" ;else: foreach(\think\Config::get('match.class') as $c=>$volc): ?>
        <option value=<?php echo $c; ?>><?php echo $volc; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>

    <select id="lev2" name="class_item">
      <?php if(is_array(\think\Config::get('match.item_1')) || \think\Config::get('match.item_1') instanceof \think\Collection || \think\Config::get('match.item_1') instanceof \think\Paginator): if( count(\think\Config::get('match.item_1'))==0 ) : echo "" ;else: foreach(\think\Config::get('match.item_1') as $i=>$voli): ?>
        <option class="item1" value=<?php echo $i; ?>><?php echo $voli; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('match.item_2')) || \think\Config::get('match.item_2') instanceof \think\Collection || \think\Config::get('match.item_2') instanceof \think\Paginator): if( count(\think\Config::get('match.item_2'))==0 ) : echo "" ;else: foreach(\think\Config::get('match.item_2') as $i=>$voli): ?>
        <option class="item2" value=<?php echo $i; ?>><?php echo $voli; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>

  </div>

  <div class="forms">
    <div class="text1">编号</div>
    <div class="text2">成绩</div>
    <div class="text3">积分</div>
    <div class="text4">破纪录</div>
  </div>

  <?php $__FOR_START_229__=1;$__FOR_END_229__=9;for($i=$__FOR_START_229__;$i < $__FOR_END_229__;$i+=1){ ?>
  <div class="forms" id="forms_<?php echo $i; ?>">

    <div class="inpid">
    <label for="aht_<?php echo $i; ?>" class="labe"><?php echo $i; ?>、</label>
    <input type="number" name="ath_<?php echo $i; ?>" id="ath_<?php echo $i; ?>" class="athletes"/>
  </div>

  <div class="ath_name" ></div>

  <div class="inpsco">
    <input type="text" name="sco_<?php echo $i; ?>" id="sco_<?php echo $i; ?>" class="score"/>
  </div>

  <div class="inping">
    <input  type="number" name="integ" id="ing_<?php echo $i; ?>" class="integ"/>
  </div>

  <div class="inpnew">
    <input  type="checkbox" value="0" id="brc_<?php echo $i; ?>" class="breakc"/>
  </div>

  </div>
  <?php } ?>

  <div class="Button">
    <button id="updata">确认</button>
  </div>

</body>
</html>
