<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:99:"C:\xampp\Demo\1875822jn8.iask.in\SUST_Sports_2018\public/../application/admin\view\login\index.html";i:1524324271;}*/ ?>
<!doctype html>
<html>
<head>
<title>Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<!-- css files -->
<link href="/SUST_Sports_2018/public/static/css/admin/login_style.css" rel='stylesheet' type='text/css' media="all" />
<!-- /js files -->
<script src="/SUST_Sports_2018/public/static/js/jquery-2.2.3.min.js"></script>
<script src="/SUST_Sports_2018/public/static/js/admin/login.js"></script>
</head>
<body>

<h1>SUST Sports 2018 Manage</h1>
<div class="log">
	<div class="content">
		<form>
			<input type="text" id="userid">
			<input type="password" id="psword">
			<div class="button-row">
				<input type="button" class="sign-in" value="登录">
			</div>
		</form>
	</div>
</div>

</body>
</html>
