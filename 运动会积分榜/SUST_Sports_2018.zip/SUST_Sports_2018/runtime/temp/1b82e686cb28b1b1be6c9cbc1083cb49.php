<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:99:"C:\xampp\Demo\1875822jn8.iask.in\SUST_Sports_2018\public/../application/index\view\event\index.html";i:1524556749;s:89:"C:\xampp\Demo\1875822jn8.iask.in\SUST_Sports_2018\application\index\view\common\base.html";i:1524556310;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>News</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/SUST_Sports_2018/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/SUST_Sports_2018/public/static/css/bootstrap.min.css">
  <script src="/SUST_Sports_2018/public/static/js/common.js"></script>
  <script src="/SUST_Sports_2018/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/SUST_Sports_2018/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/SUST_Sports_2018/public/static/css/event_style.css" />

  
<script src="/SUST_Sports_2018/public/static/js/event.js"></script>

</head>
<body background="/SUST_Sports_2018/public/static/css/../img/index_bg.jpg">
</body>
  <!-- <img src="/SUST_Sports_2018/public/static/css/../img/index_bg.jpg" class="blur"/> -->

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/SUST_Sports_2018/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

  <div class="tabl">
  <table class="table table-striped  table-bordered  table-hover text-center">

  <h3>赛事预告</h3>

  <thead>
  <tr >
	<th class="text-center">时间</th>
	<th class="text-center">比赛项目</th>
	<th class="text-center">赛次</th>
  </tr>
  </thead>

  <?php $__FOR_START_1006201994__=0;$__FOR_END_1006201994__=6;for($i=$__FOR_START_1006201994__;$i < $__FOR_END_1006201994__;$i+=1){ ?>
  <tr >
	<td><?php echo $matime[$i]['mat_time']; ?></td>
	<td><?php echo $matime[$i]['mat_name']; ?></td>
	<td><?php echo $matime[$i]['mat_status']; ?></td>
  </tr>
  <?php } ?>

  </table>
</div>

    <button id="querymatch">查询所有赛事</button>

  <br/><br/>

  <div class="table-responsive  tabl">
  </div>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
