<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:115:"C:\inetpub\wwwroot\Web\LocalUser\websustdx\SUST_Sports_2018\public/../application/index\view\interaction\index.html";i:1524676374;s:99:"C:\inetpub\wwwroot\Web\LocalUser\websustdx\SUST_Sports_2018\application\index\view\common\base.html";i:1524574908;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>SUST Sports 2018</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/websustdx/SUST_sports_2018/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/websustdx/SUST_sports_2018/public/static/css/bootstrap.min.css">
  <script src="/websustdx/SUST_sports_2018/public/static/js/common.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/websustdx/SUST_sports_2018/public/static/css/interaction_style.css" />

  
<script src="/websustdx/SUST_sports_2018/public/static/js/interaction.js"></script>

</head>
<body>
</body>
  <img src="/websustdx/SUST_sports_2018/public/static/css/../img/index_bg.jpg" class="blur"/>

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/websustdx/SUST_sports_2018/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

<h3>->> 欢迎联系我们 <<-</h3>

<img style="width:90%;margin:auto;"  src="/websustdx/SUST_sports_2018/public/static/css/../img/logo2.jpg"/ class="img-responsive" alt="Responsive image">

<br/><br/>
<h4>->> 为你准备了小游戏 <<-</h4>

<div style="width:100%;height:360px;margin:auto;" class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src='http://h5-7k7k.92game.net/H5/4239-2.html'></iframe>
</div>

<br/><br/>
<h4>如果一个不够，那就两个！</h4>

<div style="width:100%;height:480px;margin:auto;" class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src='http://www.zzfriend.com/demo/youxi/m/wjhp/'></iframe>
</div>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
