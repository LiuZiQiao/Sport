<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"C:\xampp\Demo\1875822jn8.iask.in\thinkphp\public/../application/admin\view\login\login.html";i:1522767877;}*/ ?>
<!DOCTYPE>
<html>
<head>
    <title>登录</title>
 <style>
    dl{
        text-align:center;
        border:2px solid #00CC99;
        margin-top:100px;
        margin-bottom:100px;
        margin-right:400px;
        margin-left:400px;
    }
</style>
</head>
<body>
    <div id="login_form">
<form action="http://localhost/thinkphp/public/admin/index/dologin" method="post">
    <dl>

    <dt>
        <p>用户名：<input type="text" name="username"></p>
    </dt>


    <dt>
        <p>密码：<input type="password" name="password"></p>
    </dt>


    <dt>
        <p><input type="submit" value="登录"></p>
    </dt>
    </dl>
</form>
</div>
</body>
</html>
