<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:91:"C:\xampp\Demo\1875822jn8.iask.in\thinkphp\public/../application/index\view\event\index.html";i:1523286398;s:81:"C:\xampp\Demo\1875822jn8.iask.in\thinkphp\application\index\view\common\base.html";i:1523684182;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>News</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/thinkphp/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/thinkphp/public/static/css/bootstrap.min.css">
  <script src="/thinkphp/public/static/js/common.js"></script>
  <script src="/thinkphp/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/thinkphp/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/thinkphp/public/static/css/news_style.css" />

  
<script src="/thinkphp/public/static/js/news.js"></script>

</head>
<body background="/thinkphp/public/static/css/../img/index_bg.jpg">

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/thinkphp/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

  <h3>view 前端视图 新闻页</h3>

  <div>
    <p><?php echo $news["0"]["news_title"]; ?></p>
    <!-- <img src=<?php echo $news["0"]["news_picture"]; ?> /> -->
    <p><?php echo $news["0"]["news_script"]; ?></p>
  </div>

  <br/>

  <div>
    <p><?php echo $news["1"]["news_title"]; ?></p>
    <!-- <img src=<?php echo $news["1"]["news_picture"]; ?> /> -->
    <p><?php echo $news["1"]["news_script"]; ?></p>
  </div>

  <br/>

  <div>
    <p><?php echo $news["2"]["news_title"]; ?></p>
    <!-- <img src=<?php echo $news["2"]["news_picture"]; ?> /> -->
    <p><?php echo $news["2"]["news_script"]; ?></p>
  </div>

  <br/>

  <div class="Button">
    <button>查询所有赛事</button>
  </div>

  <br/>

  <?php if(is_array($match) || $match instanceof \think\Collection || $match instanceof \think\Paginator): if( count($match)==0 ) : echo "" ;else: foreach($match as $s=>$vol): ?>
    <p><?php echo $s+1; ?> 、 <?php echo date("Y-m-d H:i",$vol['match_time']); ?> : <?php echo $vol['match_class']; ?> -> <?php echo $vol['match_item']; ?> -> <?php echo $vol['match_name']; ?></p>
  <?php endforeach; endif; else: echo "" ;endif; ?>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
