<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:109:"C:\inetpub\wwwroot\Web\LocalUser\websustdx\SUST_Sports_2018\public/../application/index\view\query\index.html";i:1524664684;s:99:"C:\inetpub\wwwroot\Web\LocalUser\websustdx\SUST_Sports_2018\application\index\view\common\base.html";i:1524574908;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>SUST Sports 2018</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/websustdx/SUST_sports_2018/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/websustdx/SUST_sports_2018/public/static/css/bootstrap.min.css">
  <script src="/websustdx/SUST_sports_2018/public/static/js/common.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/websustdx/SUST_sports_2018/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/websustdx/SUST_sports_2018/public/static/css/query_style.css" />

  
<script src="/websustdx/SUST_sports_2018/public/static/js/query.js"></script>

</head>
<body>
</body>
  <img src="/websustdx/SUST_sports_2018/public/static/css/../img/index_bg.jpg" class="blur"/>

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/websustdx/SUST_sports_2018/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

<br/>

<div class="input-group">
  <input type="text" class="form-control" id="search" placeholder="输入运动员名字或编号查询" aria-describedby="basic-addon2">
  <span class="input-group-addon" id="basic-addon2"> <span class="glyphicon glyphicon-search" aria-hidden="true"></span></span>
</div>

<div class="table-responsive1">
</div>

<h4> ->> 查询决赛排名 <<-</h4>

<div class="sele">
<select class="form-control" id="lev1" name="match_class" onclick="clicklev1(this.value)" onchange="changeitem(this.value)">
      <?php if(is_array(\think\Config::get('match.class')) || \think\Config::get('match.class') instanceof \think\Collection || \think\Config::get('match.class') instanceof \think\Paginator): if( count(\think\Config::get('match.class'))==0 ) : echo "" ;else: foreach(\think\Config::get('match.class') as $c=>$volc): ?>
        <option value=<?php echo $c; ?>><?php echo $volc; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    <select  class="form-control" id="lev2" name="class_item">
      <?php if(is_array(\think\Config::get('match.item_1')) || \think\Config::get('match.item_1') instanceof \think\Collection || \think\Config::get('match.item_1') instanceof \think\Paginator): if( count(\think\Config::get('match.item_1'))==0 ) : echo "" ;else: foreach(\think\Config::get('match.item_1') as $i=>$voli): ?>
        <option class="item1" value=<?php echo $i; ?>><?php echo $voli; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; if(is_array(\think\Config::get('match.item_2')) || \think\Config::get('match.item_2') instanceof \think\Collection || \think\Config::get('match.item_2') instanceof \think\Paginator): if( count(\think\Config::get('match.item_2'))==0 ) : echo "" ;else: foreach(\think\Config::get('match.item_2') as $i=>$voli): ?>
        <option class="item2" value=<?php echo $i; ?>><?php echo $voli; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
</div>

<div class="Button">
  <button id="queryrank">查询</button>
</div>

<div class="table-responsive2 tabl">
</div>

<h4> ->> 按学院查询 <<-</h4>

<div class="sele">
<select class="form-control" id="selcol">
  <option  selected="selected" value="01">请选择学院</option>
  <option value="01">轻工科学与工程学院</option>
  <option value="02">材料科学与工程学院</option>
  <option value="03">环境科学与工程学院</option>
  <option value="04">食品与生物工程学院</option>
  <option value="05">机电工程学院 </option>
  <option value="06">电气与信息工程学院</option>
  <option value="07">经济与管理学院</option>
  <option value="08">化学与化工学院 </option>
  <option value="09">设计与艺术学院 </option>
  <option value="10">文理学院 </option>
  <option value="11">教育学院 </option>
  <option value="12">镐京学院 </option>
</select>
</div>

<div>
  <button id="queryrank3">查询</button>
</div>

<div class="table-responsive3 tabl">
</div>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./index"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./event"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">赛事</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
