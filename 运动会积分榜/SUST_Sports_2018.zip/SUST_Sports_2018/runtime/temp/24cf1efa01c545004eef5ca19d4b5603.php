<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:90:"C:\xampp\Demo\1875822jn8.iask.in\thinkphp\public/../application/index\view\rank\index.html";i:1523108129;s:81:"C:\xampp\Demo\1875822jn8.iask.in\thinkphp\application\index\view\common\base.html";i:1523113397;}*/ ?>
<!DOCTYPE html>
<html leng="en">
<head>
  <meta charset="UFT-8">
  <title>Rank</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
  <link rel="stylesheet" type="text/css" href="/thinkphp/public/static/css/common_style.css" />
  <link rel="stylesheet" href="/thinkphp/public/static/css/bootstrap.min.css">
  <script src="/thinkphp/public/static/js/common.js"></script>
  <script src="/thinkphp/public/static/js/jquery-2.2.3.min.js"></script>
  <script src="/thinkphp/public/static/js/bootstrap.min.js"></script>
  
<link rel="stylesheet" type="text/css" href="/thinkphp/public/static/css/rank_style.css" />

  
<script src="/thinkphp/public/static/js/rank.js"></script>

</head>
<body background="/thinkphp/public/static/css/../img/index_bg.jpg">

  <div class="wrap">

    <!--头部-->
    <div class="header">
      <img src="/thinkphp/public/static/css/../img/theme.jpg"/>
    </div>

    <!--中部-->
    <div class="main">
      

<h3>view 前端视图 排行榜</h3>

<?php if(is_array($rank) || $rank instanceof \think\Collection || $rank instanceof \think\Paginator): if( count($rank)==0 ) : echo "" ;else: foreach($rank as $s=>$vol): ?>
<div class="college">
  <img class="ranking" src="/thinkphp/public/static/css/../img/college_rank/<?php echo $s+1; ?>.jpg"/>
  <div class="college_name"><?php echo $vol['college_name']; ?></div>
  <div class="score">总积分<br/><span><?php echo $vol['score']; ?></span></div>
  <hr class="line"/>
  <img class="gold" src="/thinkphp/public/static/css/../img/college_rank/gold.jpg"/>
  <div class="gold_amount"><?php echo $vol['gold']; ?></div>
  <img class="silver" src="/thinkphp/public/static/css/../img/college_rank/silver.jpg"/>
  <div class="silver_amount"><?php echo $vol['silver']; ?></div>
  <img class="copper" src="/thinkphp/public/static/css/../img/college_rank/copper.jpg"/>
  <div class="copper_amount"><?php echo $vol['bronze']; ?></div>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>


    </div>

    <!--底部-->
    <div class="bottom">
      <ul class="nav nav-tabs">
        <li id="menu1" class="col-md-3 text-center"><a href="./news"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></br><span class="litext">主页</span></a></li>
        <li id="menu2" class="col-md-3 text-center"><a href="./rank"><span class="glyphicon glyphicon-list" aria-hidden="true"></span></br><span class="litext">排行榜</span></a></li>
        <li id="menu3" class="col-md-3 text-center"><a href="./query"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></br><span class="litext">查询</span></a></li>
        <li id="menu4" class="col-md-3 text-center"><a href="./interaction"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></br><span class="litext">互动</span></a></li>
      </ul>
    </div>

</body>
</html>
