<?php
namespace app\admin\model;
use think\Model;

class Match extends Model{

}

?>
