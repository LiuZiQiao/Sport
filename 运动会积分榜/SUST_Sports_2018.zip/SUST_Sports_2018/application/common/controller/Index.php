<?php
namespace app\common\controller;

class Index
{
    public function index()
    {
        return '调用公共函数';
    }
}
