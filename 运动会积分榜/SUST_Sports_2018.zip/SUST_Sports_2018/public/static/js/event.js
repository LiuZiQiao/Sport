
$(document).ready(function(){
  $("#querymatch").click(function(){

    $.ajax({
      type: 'GET',
      url: "index/Event/ajax_mat",
      data: "",
      dataType: 'json',
      success: function(data){

        var show = '<table class="table  table-responsive  table-striped  table-bordered  table-hover text-center">'
        +'<thead>'
        +'<tr>'
        +'<th class="text-center">时间</th>'
        +'<th class="text-center">项目</th>'
        +'<th class="text-center">赛次</th>'
        +'</tr>'
        +'</thead>'

        +'<tr>'
        +'<td class="text-center" colspan="6"><span style="font-size:16px" class="text-info">4月25号</span></td>'
        +'</tr>';

        for(i=0;i<data.one.length;i++){
          show += ''
          +'<tr>'
      		+'<td>'+data.one[i]['mat_time']+'</td>'
      		+'<td>'+data.one[i]['mat_name']+'</td>'
      		+'<td>'+data.one[i]['mat_status']+'</td>'
      		+'</tr>';
        }

        show += ''
    		+'<tr>'
        +'<td class="text-center" colspan="6"><span style="font-size:16px" class="text-info">4月26号</span></td>'
        +'</tr>';

        for(i=0;i<data.two.length;i++){
          show += ''
          +'<tr>'
          +'<td>'+data.two[i]['mat_time']+'</td>'
      		+'<td>'+data.two[i]['mat_name']+'</td>'
      		+'<td>'+data.two[i]['mat_status']+'</td>'
      		+'</tr>';
        }

        $(".table-responsive").html(show);
      }
    });
  });
});
