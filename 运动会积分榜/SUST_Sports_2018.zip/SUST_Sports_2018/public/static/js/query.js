//下拉选择分类
var preclass;
var laterclass;
var i,j;

function clicklev1(c){

  switch (c) {
    case '1': preclass="item1";break;
    case '2': preclass="item2";break;
  }

}

function changeitem(c){

  switch (c) {
    case '1': laterclass="item1";break;
    case '2': laterclass="item2";break;
  }

  var prec = document.getElementsByClassName(preclass);
  var laterc = document.getElementsByClassName(laterclass);

  for(i=0;i<prec.length;i++) prec[i].style.display = "none";
  for(j=0;j<laterc.length;j++) laterc[j].style.display = "block";

  preclass = laterclass;
  var sel = document.getElementById('lev2');

  for(var i=0;i<sel.options.length;i++)
  {
     var s = sel.options[i];
     if(laterc[0].value==s.value.trim())  s.selected=true;

   }

}


//按项目查询
$(document).ready(function(){
  $("#basic-addon2").click(function(){
    var i;
    var search = document.getElementById('search').value;
    $.ajax({
      type: 'GET',
      url: "index/Query/ajax_name",
      data: 'search='+search,
      dataType: 'json',
      success: function(data){
        if(data==null||data==''){
          alert('抱歉！查询不到此结果！');
        }else{
            var show1 = '<table class="table table-striped  table-bordered  table-hover text-center">'
            +'<thead>'
            +'<tr>'
            +'<th class="text-center">姓名</th>'
            +'<th class="text-center">学院</th>'
            +'<th class="text-center">积分</th>'
            +'</tr>'
            +'</thead>';
            for(i=0;i<data.length;i++){
              show1 += '<tr>'
              +'<td>'+data[i]['ath_name']+'</td>'
              +'<td>'+data[i]['col_name']+'</td>'
              +'<td>'+data[i]['ath_integral']+'</td>'
              +'</tr>';
            }
            $(".table-responsive1").html(show1);
        }

      }
    });
  });
});


//按项目查询
$(document).ready(function(){
  $("#queryrank").click(function(){
    var i;
    var match_class = document.getElementById('lev1').value;
    var match_item = document.getElementById('lev2').value;
    $.ajax({
      type: 'GET',
      url: "index/Query/ajax_class",
      data: 'class='+match_class+'&item='+match_item,
      dataType: 'json',
      success: function(data){

        if(data!=null){

          //个人项目查询结果
          if (match_class==1)
          {
            var show1 = '<table class="table table-striped  table-bordered  table-hover text-center">'
            +'<thead>'
            +'<tr>'
            +'<th class="text-center">名次</th>'
            +'<th class="text-center">姓名</th>'
            +'<th class="text-center">学院</th>'
            +'<th class="text-center">成绩</th>'
            +'</tr>'
            +'</thead>';
            for(i=0;i<data.length;i++){
              show1 += '<tr>'
              +'<td>'+(i+1)+'</td>'
              +'<td>'+data[i]['ath_name']+'</td>'
              +'<td>'+data[i]['col_name']+'</td>'
              +'<td>'+data[i]['ath_score']+'</td>'
              +'</tr>';
            }
            $(".table-responsive2").html(show1);
          }

          //团体赛查询结果
          if (match_class==2)
          {
            var show2 = '<table class="table table-striped  table-bordered  table-hover text-center">'
            +'<thead>'
            +'<tr>'
            +'<th class="text-center">名次</th>'
            +'<th class="text-center">学院</th>'
            +'<th class="text-center">成绩</th>'
            +'</tr>'
            +'</thead>';
            for(i=0;i<data.length;i++){
              show2 += '<tr>'
              +'<td>'+(i+1)+'</td>'
              +'<td>'+data[i]['col_name']+'</td>'
              +'<td>'+data[i]['team_score']+'</td>'
              +'</tr>';
            }
            $(".table-responsive2").html(show2);
          }

        }else{
          alert('此项目暂无决赛成绩！');
        }

      }
    });
  });
});



//按学院查询
$(document).ready(function(){
  $("#queryrank3").click(function(){
    var i;
    var coll = document.getElementById('selcol').value;
    $.ajax({
      type: 'GET',
      url: "index/Query/ajax_col",
      data: 'coll='+coll,
      dataType: 'json',
      success: function(data){
        if(data!=null){
          var show1 = '<table class="table table-striped  table-bordered  table-hover text-center">'
          +'<thead>'
          +'<tr>'
          +'<th class="text-center">姓名</th>'
          +'<th class="text-center">积分</th>'
          +'</tr>'
          +'</thead>';
          for(i=0;i<data.length;i++){
            show1 += '<tr>'
            +'<td>'+data[i]['ath_name']+'</td>'
            +'<td>'+data[i]['ath_integral']+'</td>'
            +'</tr>';
          }
          $(".table-responsive3").html(show1);
        }else{
          alert('暂无记录！');
        }

      }
    });
  });
});
