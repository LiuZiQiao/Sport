$(document).ready(function(){

  $(".sign-in").click(function(){

    var ajax_url = "admin/Index/ajax_login";
    var ajax_data = "userid="+document.getElementById('userid').value+"&password="+document.getElementById('psword').value;

    $.ajax({
      type: 'GET',
      url: ajax_url,
      data: ajax_data,
      dataType: 'json',
      success: function(data){
        if(data==1){
          window.open("admin/Manage","_self",true);
        } else {
          alert(data);
        }
      },
      error: function(XMLHttpRequest, textStatus, errorThrown) {
        alert('fails!');
        // alert(XMLHttpRequest.status);
        // alert(XMLHttpRequest.readyState);
        // alert(textStatus);
      },
    });

  });
});
