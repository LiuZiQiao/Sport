


//下拉选择分类
var preclass;
var laterclass;
var i,j;

function clicklev1(c){

  switch (c) {
    case '1': preclass="item1";break;
    case '2': preclass="item2";break;
  }

}

function changeitem(c){

  switch (c) {
    case '1': laterclass="item1";break;
    case '2': laterclass="item2";break;
  }

  var prec = document.getElementsByClassName(preclass);
  var laterc = document.getElementsByClassName(laterclass);

  for(i=0;i<prec.length;i++) prec[i].style.display = "none";
  for(j=0;j<laterc.length;j++) laterc[j].style.display = "block";

  preclass = laterclass;
  var sel = document.getElementById('lev2');

  for(var i=0;i<sel.options.length;i++)
  {
     var s = sel.options[i];
     if(laterc[0].value==s.value.trim())  s.selected=true;

   }

}




//录入状态切换
window.onload=function(){

  document.getElementById('div1').value = "1";

  var div2=document.getElementById("div2");
  var div1=document.getElementById("div1");

  div2.onclick=function(){

    div1.className=(div1.className=="close1")?"open1":"close1";
    div2.className=(div2.className=="close2")?"open2":"close2";

    var i;
    var swi1 = document.getElementsByClassName("inpsco");
    var swi2 = document.getElementsByClassName("inping");
    var swi3 = document.getElementsByClassName("inpnew");
    var txt1 = document.getElementsByClassName("text2");
    var txt2 = document.getElementsByClassName("text3");
    var txt3 = document.getElementsByClassName("text4");

    if(div1.className=="close1"){

      for(i=0;i<swi1.length;i++){
        swi1[i].style.display = "none";
        swi2[i].style.display = "none";
        swi3[i].style.display = "none";
      }

      txt1[0].style.display = "none";
      txt2[0].style.display = "none";
      txt3[0].style.display = "none";
      document.getElementById("stat").innerHTML = "当前状态：录入晋级决赛名单";
      document.getElementById('div1').value = "0";

    }else {

      for(i=0;i<swi1.length;i++){
        swi1[i].style.display = "block";
        swi2[i].style.display = "block";
        swi3[i].style.display = "block";
      }

      txt1[0].style.display = "block";
      txt2[0].style.display = "block";
      txt3[0].style.display = "block";
      document.getElementById("stat").innerHTML = "当前状态：录入比赛成绩排名";
      document.getElementById('div1').value = "1";
    }
  }
}




//提交按钮(异步)
$(document).ready(function(){

  $("button").click(function(){

    var i;
    var x=0;
    //用于校验录入的信息存在错误
    var is = true;
    //用于验证信息是否完整
    var iss = false;
    //判断全空
    for(i=0;i<8;i++){
      if(document.getElementsByClassName('ath_name')[i].innerHTML!="") {
         break;
      }
      if(i>=7)  is=false;
    }
    //判断编号存在错误
    for(i=0;i<8;i++){
      if(document.getElementsByClassName('ath_name')[i].innerHTML=="error!"){
        is = false;
        break;
      }
    }
    //如果不是全空且编号没有错误执行
    if(is){
      var str = document.getElementById('div1').value=="1"?"确定提交比赛成绩排名吗？":"确定提交晋级决赛名单吗？";

      var ajax_url = document.getElementById('div1').value=="1"?"./Manage/ajax_fin":"./Manage/ajax_pro";

      if(document.getElementById('div1').value=="1"){

        var ranarr = new Array();
        var scoarr = new Array();
        var ingarr = new Array();
        var newarr = new Array();

        for(i=0;i<8;i++){
          ranarr[i] = document.getElementsByClassName("athletes")[i].value;
          scoarr[i] = document.getElementsByClassName("score")[i].value;
          ingarr[i] = document.getElementsByClassName("integ")[i].value;
          newarr[i] = document.getElementsByClassName("breakc")[i].value;
        }

        //获取有效运动员个数
        for(i=0;i<ranarr.length;i++){
          if (ranarr[i]=='') {
            x = i;
            break;
          }
        }

        var ranks = ranarr.toString();
        var scores = scoarr.toString();
        var ingstr = ingarr.toString();
        var newstr = newarr.toString();

        var ajax_data = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&ranks="+ranks+"&scores="+scores+"&integrals="+ingstr+"&newcor="+newstr;

      }else{

        var ranarr = new Array();
        for(i=0;i<8;i++)  ranarr[i] = document.getElementsByClassName("athletes")[i].value;
        var ranks = ranarr.toString();
        var ajax_data = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&ranks="+ranks;
        //录入晋级决赛名单不需要验证信息完整性，默认为真
        iss = true;
      }
      // 验证信息完整性
      for(i=0;i<x+1;i++){
        if(scoarr[i]==''||ingarr[i]=='') break;
        if(i>=x-1) iss = true;
      }
      // 如果信息完整执行
      if(iss){
        if(confirm(str)){
          $.ajax({
            type: 'GET',
            url: ajax_url,
            data: ajax_data,
            dataType: 'json',
            success: function(data){
              if(data=='111')  alert("录入成功！");
              else {
                alert("存在错误："+data+",请不要再次提交！");
              }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
              alert('error!');
              // alert(XMLHttpRequest.status);
              // alert(XMLHttpRequest.readyState);
              // alert(textStatus);
            },
          });
          return true;
        } else {
          return false;
        }
      }else{
        alert('信息不完整！');
      }
    }else{
      alert('录入信息存在错误！');
    }
  });
});




//运动员/团队编号校验
$(document).ready(function(){

  var i = 0;
  var a = new Array();
  for(i=0;i<8;i++)  a[i] = i+1;

  $('#ath_'+a[0]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[0]).val();

    if($('#ath_'+a[0]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&&data.part==1){

            document.getElementsByClassName('ath_name')[a[0]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[0]-1].style.color = "black";

          }else{

            document.getElementsByClassName('ath_name')[a[0]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[0]-1].style.color = "red";

          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[0]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[0]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[0]-1].innerHTML = "";
    }
  });



  $('#ath_'+a[1]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[1]).val();

    if($('#ath_'+a[1]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&data.part==1){

            document.getElementsByClassName('ath_name')[a[1]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[1]-1].style.color = "black";

          }else{

            document.getElementsByClassName('ath_name')[a[1]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[1]-1].style.color = "red";

          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[1]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[1]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[1]-1].innerHTML = "";
    }
  });



  $('#ath_'+a[2]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[2]).val();

    if($('#ath_'+a[2]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&data.part==1){

            document.getElementsByClassName('ath_name')[a[2]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[2]-1].style.color = "black";

          }else{
            document.getElementsByClassName('ath_name')[a[2]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[2]-1].style.color = "red";
          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[2]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[2]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[2]-1].innerHTML = "";
    }
  });



  $('#ath_'+a[3]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[3]).val();

    if($('#ath_'+a[3]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&data.part==1){

            document.getElementsByClassName('ath_name')[a[3]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[3]-1].style.color = "black";
          }else{

            document.getElementsByClassName('ath_name')[a[3]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[3]-1].style.color = "red";

          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[3]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[3]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[3]-1].innerHTML = "";
    }
  });



  $('#ath_'+a[4]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[4]).val();

    if($('#ath_'+a[4]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&data.part==1){

            document.getElementsByClassName('ath_name')[a[4]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[4]-1].style.color = "black";

          }else{

            document.getElementsByClassName('ath_name')[a[4]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[4]-1].style.color = "red";

          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[4]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[4]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[4]-1].innerHTML = "";
    }
  });



  $('#ath_'+a[5]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[5]).val();

    if($('#ath_'+a[5]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&data.part==1){

            document.getElementsByClassName('ath_name')[a[5]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[5]-1].style.color = "black";

          }else{

            document.getElementsByClassName('ath_name')[a[5]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[5]-1].style.color = "red";

          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[5]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[5]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[5]-1].innerHTML = "";
    }
  });



  $('#ath_'+a[6]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[6]).val();

    if($('#ath_'+a[6]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&data.part==1){

            document.getElementsByClassName('ath_name')[a[6]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[6]-1].style.color = "black";

          }else{

            document.getElementsByClassName('ath_name')[a[6]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[6]-1].style.color = "red";

          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[6]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[6]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[6]-1].innerHTML = "";
    }
  });



  $('#ath_'+a[7]).bind('input propertychange', function() {

    nlen = document.getElementById('lev1').value=="1"?3:1;
    var ajax_curl = "./Manage/ajax_check";
    var ajax_cdat = "class="+document.getElementById('lev1').value+"&item="+document.getElementById('lev2').value+"&cheid="+$('#ath_'+a[7]).val();

    if($('#ath_'+a[7]).val().length>nlen){

      $.ajax({
        type: 'GET',
        url: ajax_curl,
        data: ajax_cdat,
        dataType: 'json',
        success: function(data){

          if(data.effe!=null&data.part==1){

            document.getElementsByClassName('ath_name')[a[7]-1].innerHTML = data.effe[0]["ath_name"];
            document.getElementsByClassName('ath_name')[a[7]-1].style.color = "black";

          }else{

            document.getElementsByClassName('ath_name')[a[7]-1].innerHTML = "error!";
            document.getElementsByClassName('ath_name')[a[7]-1].style.color = "red";

          }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          document.getElementsByClassName('ath_name')[a[7]-1].innerHTML = "error!";
          document.getElementsByClassName('ath_name')[a[7]-1].style.color = "red";
          // alert(XMLHttpRequest.status);
          // alert(XMLHttpRequest.readyState);
          // alert(textStatus);
        },
      });
    } else {
      document.getElementsByClassName('ath_name')[a[7]-1].innerHTML = "";
    }
  });




  //破纪录选择框
  $('#brc_'+a[0]).click(function(){
    var newv = $('#brc_'+a[0]).val();
    document.getElementsByClassName('breakc')[a[0]-1].value = newv=='1'?'0':'1';
    if(document.getElementsByClassName('breakc')[a[0]].checked == true){
      $('#brc_'+(a[0]+1)).click();
    }

  });


  $('#brc_'+a[1]).click(function(){
    var newv = $('#brc_'+a[1]).val();
    if(document.getElementsByClassName('breakc')[a[1]-2].checked == true){
      document.getElementsByClassName('breakc')[a[1]-1].value = newv=='1'?'0':'1';
    } else {
      document.getElementsByClassName('breakc')[a[1]-1].checked = false;
    }
    if(document.getElementsByClassName('breakc')[a[1]].checked == true){
      $('#brc_'+(a[1]+1)).click();
    }
  });


  $('#brc_'+a[2]).click(function(){
    var newv = $('#brc_'+a[2]).val();
    if(document.getElementsByClassName('breakc')[a[2]-2].checked == true){
      document.getElementsByClassName('breakc')[a[2]-1].value = newv=='1'?'0':'1';
    } else {
      document.getElementsByClassName('breakc')[a[2]-1].checked = false;
    }
    if(document.getElementsByClassName('breakc')[a[2]].checked == true){
      $('#brc_'+(a[2]+1)).click();
    }
  });


  $('#brc_'+a[3]).click(function(){
    var newv = $('#brc_'+a[3]).val();
    if(document.getElementsByClassName('breakc')[a[3]-2].checked == true){
      document.getElementsByClassName('breakc')[a[3]-1].value = newv=='1'?'0':'1';
    } else {
      document.getElementsByClassName('breakc')[a[3]-1].checked = false;
    }
    if(document.getElementsByClassName('breakc')[a[3]].checked == true){
      $('#brc_'+(a[3]+1)).click();
    }
  });


  $('#brc_'+a[4]).click(function(){
    var newv = $('#brc_'+a[4]).val();
    if(document.getElementsByClassName('breakc')[a[4]-2].checked == true){
      document.getElementsByClassName('breakc')[a[4]-1].value = newv=='1'?'0':'1';
    } else {
      document.getElementsByClassName('breakc')[a[4]-1].checked = false;
    }
    if(document.getElementsByClassName('breakc')[a[4]].checked == true){
      $('#brc_'+(a[4]+1)).click();
    }
  });


  $('#brc_'+a[5]).click(function(){
    var newv = $('#brc_'+a[5]).val();
    if(document.getElementsByClassName('breakc')[a[5]-2].checked == true){
      document.getElementsByClassName('breakc')[a[5]-1].value = newv=='1'?'0':'1';
    } else {
      document.getElementsByClassName('breakc')[a[5]-1].checked = false;
    }
    if(document.getElementsByClassName('breakc')[a[5]].checked == true){
      $('#brc_'+(a[5]+1)).click();
    }
  });


  $('#brc_'+a[6]).click(function(){
    var newv = $('#brc_'+a[6]).val();
    if(document.getElementsByClassName('breakc')[a[6]-2].checked == true){
      document.getElementsByClassName('breakc')[a[6]-1].value = newv=='1'?'0':'1';
    } else {
      document.getElementsByClassName('breakc')[a[6]-1].checked = false;
    }
    if(document.getElementsByClassName('breakc')[a[6]].checked == true){
      $('#brc_'+(a[6]+1)).click();
    }
  });


  $('#brc_'+a[7]).click(function(){
    var newv = $('#brc_'+a[7]).val();
    if(document.getElementsByClassName('breakc')[a[7]-2].checked == true){
      document.getElementsByClassName('breakc')[a[7]-1].value = newv=='1'?'0':'1';
    } else {
      document.getElementsByClassName('breakc')[a[7]-1].checked = false;
    }
  });


});
