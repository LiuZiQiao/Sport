<?php
return [
  'event/' => 'index/Event/index',
  'query/' => 'index/Query/index',
  'interaction/' => 'index/Interaction/index'
]
 ?>
